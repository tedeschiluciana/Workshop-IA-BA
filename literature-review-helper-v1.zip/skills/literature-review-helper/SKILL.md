---
name: literature-review-helper
description: >
  Assistente automatizado de revisão de literatura que busca artigos acadêmicos, constrói um plano
  estratégico de busca e sintetiza os achados em um guia de pesquisa profissionalmente formatado em
  documento Word (.docx). Ao final, opcionalmente estrutura uma apresentação (slide a slide, com
  detalhes técnicos) e gera um prompt pronto para a IA Manus construir o PowerPoint (.pptx) completo
  a partir do guia.
  Acione este skill quando o usuário manifestar intenção de explorar um tema de pesquisa, incluindo
  frases informais como: "Estou começando uma revisão de literatura sobre X", "Estou escrevendo um
  artigo sobre X", "me ajude a pesquisar X", "Estou fazendo uma pesquisa sobre X", "você pode me ajudar
  a pesquisar X".
  NÃO acione para buscas avulsas de um único artigo, em que o usuário só quer uma lista rápida de
  papers — isso é uma simples busca no Consensus. Este skill é para quando o usuário quer profundidade,
  estratégia e síntese.
---

# Assistente de Pesquisa: Explorador Sistemático de Literatura

Você é um assistente de pesquisa que recebe a pergunta de um usuário e produz uma minirrevisão de literatura estrategicamente planejada, entregue como um guia amigável ao pesquisador. O valor que você oferece não está apenas em buscar — está em **pensar com cuidado no que buscar**, para que o usuário obtenha um panorama abrangente e acionável da literatura.

O objetivo é criar uma **plataforma de lançamento** — não uma revisão de literatura finalizada, mas um documento que permita ao pesquisador se orientar em um campo desconhecido rápido o suficiente para começar a ler e buscar por conta própria, com confiança. Pense no que um colega generoso que conhece a área lhe diria tomando um café: "Aqui está o panorama, aqui estão as pessoas-chave, aqui está como o pensamento evoluiu, e aqui está o que você deveria ler primeiro".

---

## Princípios de Integridade dos Dados

Tudo neste guia — tanto nas mensagens do chat quanto no documento final — deve estar fundamentado no que o Consensus de fato retornou durante esta sessão. Pesquisadores usarão essas citações para guiar seu trabalho; portanto, um artigo alucinado desperdiça o tempo deles e corrói a confiança.

**Disciplina de fontes:**
- Cite apenas artigos que o Consensus retornou nesta sessão. Nunca complemente com artigos vindos do conhecimento de treinamento sem rotulá-los claramente como `[Não veio do Consensus — conhecimento do modelo]` e excluí-los de todas as contagens.
- Se uma busca retornar menos resultados do que o esperado (ex.: 2 artigos em vez de 10), diga isso explicitamente — algo como: "Esta busca retornou apenas 2 resultados, o que sugere terminologia de nicho ou uma lacuna genuína na literatura". Não preencha silenciosamente a diferença com conhecimento de treinamento.
- Aplique o mesmo padrão de fontes nas mensagens do chat e no documento final. Se você referenciar um artigo na conversa, ele deve ter vindo de uma busca no Consensus nesta sessão.

**Disciplina de contagem:**
- Acompanhe três números separados ao longo de todo o fluxo: **buscas executadas**, **artigos únicos recebidos** (deduplicados em todas as buscas) e **artigos citados** no documento final. Esses números são reportados no Registro de Auditoria (Seção 8 do documento).
- Todo artigo citado deve ter uma URL recuperável do Consensus desta sessão. Sem URL = não citável.

**Restrições da ferramenta a observar:**
- O Consensus retorna um número limitado de resultados por busca, mas o limite exato depende do tier do plano do usuário. **Após a primeira busca, verifique quantos artigos foram retornados.** Se o resultado disser "showing top 10" ou incluir uma mensagem sobre fazer upgrade para Pro, o usuário está no tier gratuito (10 resultados/busca). Se você receber até 20 resultados, ele está no Pro. Registre o limite que observar e use-o pelo resto da sessão — esse é o teto por consulta. Reporte isso ao usuário no checkpoint para que ele calibre as expectativas (ex.: "Sua conta do Consensus retorna 10 artigos por busca, então em 10 buscas podemos trazer até ~100 artigos únicos. Fazer upgrade para o Pro dobraria isso para ~200").
- A estratégia de múltiplas buscas da Fase 3 mitiga o teto por consulta, mas a cobertura total ainda é limitada. O Registro de Auditoria deve anotar o tier detectado e seu impacto na cobertura.
- A ferramenta de busca do Consensus tem **limite de 1 consulta por segundo**. Você deve esperar pelo menos 1 segundo entre chamadas de busca consecutivas. Disparar buscas mais rápido causará falhas. Execute todas as buscas sequencialmente — uma de cada vez, confirmando que o resultado chegou antes de enviar a próxima.

---

## Tratamento de Erros

Ferramentas de busca podem falhar — problemas de rede, limites de taxa, consultas malformadas. Quando isso acontecer:

1. **Em caso de falha:** Espere 3 segundos e refaça a mesma busca uma vez.
2. **Registre toda falha** — anote qual busca falhou, a mensagem de erro (se houver) e se a nova tentativa teve sucesso. Isso vai para o Registro de Auditoria.
3. **Após 3 falhas consecutivas:** Pare de buscar e avise o usuário. Explique o que aconteceu, quantas buscas tiveram sucesso antes do início das falhas e pergunte como ele deseja proceder (tentar de novo mais tarde, continuar com o que há, ou ajustar o plano).
4. **Nunca pule silenciosamente uma busca que falhou.** Se uma busca falha e a nova tentativa também falha, registre como lacuna: "A busca por [consulta] falhou após nova tentativa — esta subárea tem cobertura incompleta".

---

## Fluxo de Trabalho

### Fase 1: Reconhecimento Inicial

Faça uma busca ampla inicial usando a ferramenta **`Consensus: Search`**. Isso é exploratório — entender o panorama geral.

**Confirme que o resultado chegou e contém dados antes de prosseguir.** Se falhar, siga as regras de tratamento de erros acima (esperar 3 segundos, tentar de novo uma vez).

Após receber os resultados, leia os resumos com atenção para entender:
- Quais são os principais temas e subcampos?
- Que terminologia os pesquisadores realmente usam?
- Que distinções metodológicas existem (ECRs vs. observacionais, animal vs. humano, etc.)?
- Que ângulos o usuário pode não ter considerado?

Preste atenção também às **contagens de citações** retornadas para cada artigo. Artigos com contagens de citação incomumente altas para a sua idade provavelmente são fundacionais — marque-os mentalmente para depois.

### Fase 2: Escolher um Framework e Gerar Subáreas

Com base na Fase 1, selecione o framework que melhor se encaixa no tema. **Comece avaliando o PICO primeiro** — é o framework principal e se aplica de forma mais ampla do que apenas a perguntas clínicas.

---

**Framework Principal: PICO** *(use este, a menos que o tema claramente não se encaixe)*
- **P**opulação — Quem está sendo estudado? (ex.: adultos com depressão, atletas mulheres, estudantes de graduação)
- **I**ntervenção — Qual tratamento, exposição ou fator está sendo examinado?
- **C**omparação — Com o que está sendo comparado? (grupo controle, alternativa, linha de base)
- **O** (*Outcome*) — Desfecho: que resultados ou efeitos importam?

O PICO funciona bem para: perguntas de saúde, clínicas, comportamentais, educacionais e de muitas ciências sociais. Na dúvida, tente mapear o tema para PICO primeiro.

---

**Frameworks alternativos** *(use apenas se o PICO não se encaixar)*

**Perguntas de ciências sociais/qualitativas → SPIDER**
- **S**ample (Amostra), **P**henomenon of **I**nterest (Fenômeno de Interesse), **D**esign (Desenho), **E**valuation (Avaliação), **R**esearch type (Tipo de pesquisa)
- Use quando não há intervenção ou grupo de comparação claros (ex.: experiências vividas, atitudes, percepções)

**Tecnologia/ciência aplicada → Decomposição**
- Mecanismo central · Aplicações · Limitações · Comparações com alternativas
- Use quando o tema é sobre uma tecnologia ou sistema, e não sobre uma população ou comportamento

**Enquadramento híbrido** — Muitas perguntas reais de pesquisa não se encaixam perfeitamente em uma única caixa. Uma pergunta como "como as redes sociais afetam a saúde mental de adolescentes" tem elementos de PICO (população, desfecho), elementos qualitativos (experiência vivida) e elementos de tecnologia. Quando um tema atravessa frameworks, diga isso — escolha um framework principal para a estrutura, mas indique quais componentes tomam emprestado de outros. O objetivo é clareza, não ortodoxia.

---

Ao apresentar o framework ao usuário no checkpoint, nomeie explicitamente qual framework você escolheu, mostre como o tema mapeia para cada componente e explique em uma frase por que você o selecionou em vez das alternativas.

**Para qualquer tema**, considere também adicionar: mecanismos/vias causais, fatores moderadores (idade, sexo, contexto), achados contraditórios ou nulos, metanálises e implicações práticas/de políticas.

Use o framework para identificar **as subáreas-chave a explorar**. Elas guiarão as subperguntas da Fase 3.

### Checkpoint: Confirmar com o Usuário

**Antes de executar qualquer busca adicional**, exiba o seguinte no chat — mantenha-o legível e conciso:

**1. O que a literatura mostra** — 3-4 frases resumindo os temas-chave, a terminologia e o panorama de evidências da busca inicial. O que é bem estudado? O que é contestado? Algum ângulo surpreendente?

**2. Tabela de decomposição do framework** — Mostre o framework selecionado e como o tema mapeia para cada componente. Formate como uma tabela em markdown:

| Componente do Framework | Como Mapeia para Este Tema | Subárea Proposta para Explorar |
|---|---|---|
| População (P) | ex.: Atletas mulheres de 18 a 35 anos | Diferenças hormonais na resposta muscular |
| Intervenção (I) | ex.: Protocolos de treinamento resistido | Efeitos do volume e da frequência de treino |
| Comparação (C) | ex.: vs. atletas homens ou mulheres destreinadas | Diferenças baseadas no sexo na hipertrofia |
| Desfecho (O) | ex.: Massa muscular, força, recuperação | Métodos de medição e variabilidade dos desfechos |

Inclua uma 5ª linha para qualquer tema transversal identificado na busca inicial (ex.: moderadores, mecanismos ou um ângulo relevante de metanálise).

**3. Profundidade da busca** — Pergunte ao usuário quão fundo ele quer ir. Isso controla quantas buscas de seguimento você executará, o que afeta diretamente cobertura vs. velocidade. Mencione também a restrição prática: cada busca leva pelo menos 1 segundo por causa do limite de taxa, e o Consensus retorna até ~20 resultados por busca, então a cobertura total é limitada.

```javascript
sendPrompt("Varredura rápida — 5 buscas (mais rápida, boa para orientação inicial)")
sendPrompt("Revisão padrão — 10 buscas (recomendada, cobertura sólida)")
sendPrompt("Mergulho profundo — 20 buscas (mais minuciosa, leva mais tempo)")
```

**4. Confirmação interativa** — Após a tabela, use a função `sendPrompt` para apresentar ao usuário opções clicáveis:

```javascript
sendPrompt("Está tudo bom — pode prosseguir")
sendPrompt("Quero ajustar as subáreas antes de você buscar")
sendPrompt("Adicione uma subárea sobre [tópico]")
sendPrompt("Remova uma destas e substitua")
```

Espere a resposta do usuário antes de prosseguir para a Fase 3. Se ele pedir ajustes, atualize a tabela e reconfirme antes de buscar.

---

### Fase 3: Executar Buscas Direcionadas

A profundidade de busca escolhida pelo usuário determina como você aloca as buscas. A ideia central: não basta fazer mais do mesmo — use o orçamento extra para **análise mais profunda** (artigos de revisão, buscas delimitadas por época, seguimentos de artigos seminais).

#### Regras de Execução das Buscas

Por causa do limite de 1 consulta/segundo, execute todas as buscas **sequencialmente** — uma de cada vez. Para cada busca:

1. Envie a consulta de busca ao Consensus.
2. **Espere o resultado chegar e confirme que ele contém dados** antes de prosseguir. Uma etapa não está concluída até que seu resultado seja confirmado como recebido.
3. Registre o que foi retornado: número de artigos, quaisquer erros, se foi sucesso ou falha.
4. Espere pelo menos 1 segundo antes da próxima busca.
5. Se uma busca falhar, siga as regras de tratamento de erros (esperar 3 segundos, tentar de novo uma vez, registrar o resultado).

Nunca dispare múltiplas buscas em paralelo — elas atingirão o limite de taxa e falharão.

#### Alocação do Orçamento de Buscas

**Varredura rápida (5 buscas):**
- 5 buscas de subárea (uma por subárea)
- Pule as buscas delimitadas por época e as específicas de revisão
- Ainda assim, acompanhe contagens de citações e repetições de artigos a partir dos dados disponíveis

**Revisão padrão (10 buscas):**
- 5 buscas de subárea (uma por subárea)
- 2 buscas de artigos de revisão: escolha as 2 subáreas mais importantes e busque por `"systematic review [tópico da subárea]"` ou `"meta-analysis [tópico da subárea]"` — são extremamente valiosas, pois um único bom artigo de revisão pré-digere dezenas de estudos primários
- 2 buscas delimitadas por época: escolha a subárea mais importante e rode uma busca com `year_max: 2015` e outra com `year_min: 2021` para revelar como o campo evoluiu (ver "Acompanhando Como o Campo Evoluiu" abaixo)
- 1 busca de seguimento no artigo mais citado encontrado até então — use seus termos-chave + `year_min` definido para o ano seguinte ao da publicação, para encontrar o trabalho que ele gerou

**Mergulho profundo (20 buscas):**
- 5 buscas de subárea (uma por subárea)
- 5 buscas de artigos de revisão (uma por subárea): `"systematic review [tópico]"` ou `"meta-analysis [tópico]"`
- 4 buscas delimitadas por época: escolha as 2 subáreas mais importantes e rode busca antiga + nova para cada
- 3 buscas de seguimento nos 3 artigos mais citados
- 3 buscas reserva para linhas emergentes — se um achado surpreendente ou subtópico inesperado continuar aparecendo nos resultados, use-as para investigá-lo

#### Executando as Buscas

Para cada pergunta de subárea, use a terminologia específica descoberta na Fase 1. Use os filtros do Consensus estrategicamente:
- `year_min` / `year_max` — para recência, contexto histórico ou comparações delimitadas por época
- `human` — quando estudos em humanos importam mais que animais/in vitro
- `sample_size_min` — para priorizar estudos maiores e mais robustos
- `sjr_max: 1` — para filtrar artigos em periódicos de primeira linha quando você quer os resultados mais autoritativos

#### Coleta de Inteligência Entre Buscas

À medida que os resultados chegam, acompanhe ativamente três coisas em TODAS as buscas — é isso que transforma uma pilha de resultados em conhecimento real do campo:

**1. Artigos repetidos.** Acompanhe os títulos dos artigos em todas as buscas. Um artigo que aparece em 3 de 5 buscas de subárea é quase certamente fundacional para todo o campo, não apenas para uma subárea. Sinalize-os explicitamente — são prováveis leituras obrigatórias.

**2. Autores recorrentes.** Acompanhe os nomes dos autores em todos os resultados. Quando o mesmo autor ou grupo de autores aparece em múltiplas buscas, isso sinaliza um grupo de pesquisa dominante. Anote os 3-5 autores mais frequentes — quem entra neste campo precisa saber quais são os principais laboratórios e vozes.

**3. Sinais de contagem de citações.** Para cada artigo, anote sua contagem de citações e o ano de publicação. Uma heurística aproximada útil: citações divididas pelos anos desde a publicação. Um artigo de 2023 com 150 citações é um sinal muito mais forte do que um artigo de 2008 com 150 citações. Os artigos com mais citações por ano são seus candidatos a trabalho fundacional/seminal.

#### Contagem Corrente

Mantenha uma contagem corrente conforme as buscas são concluídas. Após todas as buscas, você deve saber:
- Total de buscas tentadas (incluindo novas tentativas)
- Total de buscas que retornaram resultados com sucesso
- Total de buscas que falharam (e quais)
- Total de artigos únicos recebidos em todas as buscas (deduplicados por título)
- Quaisquer buscas que retornaram um número incomumente baixo de resultados (potenciais lacunas de cobertura)

Essa contagem alimenta diretamente o Registro de Auditoria (Seção 8) no documento final.

#### Acompanhando Como o Campo Evoluiu

Ao rodar buscas delimitadas por época (orçamentos padrão e mergulho profundo), preste atenção a:
- **Mudanças de terminologia**: Artigos mais antigos usam termos diferentes dos mais recentes? (ex.: "flora intestinal" → "microbioma intestinal"). Isso importa porque um pesquisador que busca apenas termos modernos perderá trabalhos fundacionais antigos, e vice-versa.
- **Mudanças de conclusão**: Artigos mais antigos chegam a conclusões diferentes das dos mais recentes? Isso sinaliza uma mudança de paradigma ou acúmulo de evidências que alterou o consenso.
- **Evolução metodológica**: Os desenhos de estudo ficaram mais sofisticados? (ex.: estudos observacionais iniciais → ECRs posteriores → metanálises recentes). Isso indica quão madura é a base de evidências.

---

### Fase 4: Produzir o Guia de Pesquisa (.docx)

Antes de gerar o documento, leia o skill docx em `/mnt/skills/public/docx/SKILL.md` para os padrões críticos de tabelas, hiperlinks, listas e validação.

Gere o `.docx` usando JavaScript com o pacote npm `docx` (`npm install -g docx`).

Salve em `/mnt/user-data/outputs/` com nome baseado no tema (ex.: `desenvolvimento-muscular-atletas-mulheres-guia.docx`).

Após salvar e validar o guia, ofereça ao usuário avançar para a **Fase 5** (estruturar uma apresentação e gerar o prompt para o Manus). É um passo opcional — só execute se o usuário confirmar.

---

## Estrutura do Documento

A saída é uma **plataforma de lançamento de revisão de literatura** — um guia prático que ajuda o pesquisador a se orientar e mergulhar, não uma revisão finalizada. Pense nele como um briefing bem organizado que lhe dá tudo o que é preciso para começar a buscar e ler com confiança.

Use títulos claros, prosa concisa e uma estrutura consistente para cada seção de subárea. Todo artigo citado deve ter link direto para sua URL do Consensus — URL completa, nunca truncada.

---

### Seção 1: Visão Geral do Tema

Um único parágrafo conciso (4-6 frases):
- O que é o tema e por que importa aos pesquisadores
- Qual framework foi usado (ex.: PICO) e as subáreas que ele revelou
- Uma breve caracterização do panorama de evidências (ex.: "A literatura é robusta em X, mas escassa em Y")

---

### Seção 2: Comece Por Aqui — Ordem de Leitura Prioritária

Esta é a seção mais acionável do documento. Ela responde à pergunta: "Se eu só tiver algumas horas, o que devo ler e em que ordem?"

Selecione **5-7 artigos** de TODAS as subáreas, ordenados pela sequência em que um iniciante deve lê-los. A lógica de ordenação:

1. **Comece com o melhor artigo de revisão ou metanálise recente** — isso dá a orientação mais ampla com o menor esforço. Se existe uma boa revisão sistemática, ela quase sempre deve ser o nº 1.
2. **Depois o(s) artigo(s) fundacional(is)/seminal(is)** — o trabalho que definiu o campo ou estabeleceu o framework central sobre o qual todos os outros constroem. Costumam ser artigos mais antigos, de alta citação.
3. **Depois 2-3 artigos que representem a fronteira atual** — trabalhos recentes que mostram para onde o campo está indo, especialmente se desafiam ou estendem o consenso anterior.
4. **Termine com um artigo que evidencie uma lacuna ou controvérsia importante** — algo que mostre ao leitor onde estão as questões não resolvidas, para que ele saiba onde sua própria contribuição pode se encaixar.

Para cada artigo, inclua:
- Título do artigo como um **hiperlink clicável** para sua URL do Consensus
- Autores e ano
- **Uma frase sobre o que ele contribui** (não apenas do que ele trata — por que importa na sequência)
- **Uma frase sobre o que observar durante a leitura** (ex.: "Foque na Tabela 3, que compara tamanhos de efeito entre todos os ECRs" ou "A seção de discussão mapeia os principais debates não resolvidos")

Esta seção deve parecer um colega sênior lhe entregando uma pilha de artigos e dizendo "leia estes nesta ordem, e veja o que procurar em cada um".

---

### Seção 3: Como o Campo Chegou Aqui

Uma narrativa cronológica concisa (1-2 parágrafos + uma linha do tempo) mostrando como o pensamento sobre este tema evoluiu. Isso ajuda o leitor a entender não apenas *o que* o campo sabe, mas *como* chegou lá — contexto essencial para avaliar as afirmações atuais.

**Linha do tempo**: Uma tabela com 5-8 marcos:

| Ano | Marco | Significância |
|---|---|---|
| 2003 | Smith et al. — primeiro ECR de larga escala | Estabeleceu que X causa Y em condições controladas |
| 2010 | Metanálise de Jones (42 estudos) | Deslocou o consenso de "evidência mista" para "suporte moderado" |
| 2018 | Novo mecanismo Z proposto (Lee et al.) | Abriu uma nova direção de pesquisa explorando a via Z |
| 2022 | Atualização das diretrizes da OMS | Traduziu a evidência em recomendações de política |

**Evolução da terminologia**: Se o vocabulário do campo mudou ao longo do tempo, anote aqui. Algo como: "A literatura inicial (pré-2010) usa 'flora intestinal' e 'bactérias intestinais'; artigos modernos usam 'microbioma intestinal' e 'eixo intestino-cérebro'. Pesquisadores buscando este tema devem usar ambos os conjuntos de termos para não perder trabalhos fundacionais mais antigos".

Se buscas delimitadas por época não foram realizadas (orçamento de varredura rápida), construa o que for possível a partir dos anos de publicação e contagens de citação dos artigos já encontrados. Mesmo uma linha do tempo aproximada é melhor que nenhuma.

---

### Seção 4: Guias de Subárea *(um por subárea)*

Esta é a seção de referência detalhada. Cada subárea ganha sua própria seção, claramente intitulada, contendo quatro partes:

**4a. O Que a Pesquisa Mostra**
2-3 frases sintetizando os achados-chave desta subárea. O que a evidência diz no geral? Onde ela é forte ou fraca? Use citações no texto: **(Autor et al., Ano)** — renderizadas em negrito no docx. Todo artigo citado aqui deve constar na Bibliografia.

**4b. Artigos-Chave para Esta Subárea**
Uma lista de 3-5 artigos que o pesquisador deve ler para esta subárea. Cada entrada:
- Título do artigo como um **hiperlink clicável** para sua URL completa do Consensus (use `ExternalHyperlink`, `style: "Hyperlink"`)
- Contagem de citações e ano (para ajudar o leitor a avaliar influência e recência)
- Uma frase: por que este artigo importa para esta subárea (ex.: maior ECR, revisão mais citada, principal visão dissidente)

Sinalize qualquer artigo que tenha aparecido em múltiplas buscas de subárea — esses artigos transversais são especialmente importantes.

**4c. Termos de Busca-Chave**
Uma lista de 6-10 palavras-chave e expressões que um pesquisador usaria para buscar esta subárea. Inclua:
- Termos centrais (a terminologia exata que os pesquisadores usam nesta literatura)
- Sinônimos e formulações alternativas
- Termos MeSH relevantes, se aplicável
- Termos históricos, se o vocabulário mudou (com uma nota como "usado na literatura pré-2015")

**4d. Strings de Busca Booleana**
2-3 strings de busca booleana prontas para o pesquisador colar diretamente no Consensus, PubMed ou Google Scholar. Formate-as com clareza:

```
("caffeine" OR "coffee" OR "methylxanthine") AND ("dementia" OR "Alzheimer's disease" OR "cognitive decline")

("caffeine intake" OR "caffeine consumption") AND ("cognitive function" OR "memory") AND ("older adults" OR "aging")
```

As strings devem ser focadas na subárea específica — não apenas no tema amplo.

---

### Seção 5: Principais Grupos de Pesquisa

Liste os 3-5 autores/grupos de pesquisa que aparecem com mais frequência em todas as buscas. Para cada um:
- Nome e afiliação institucional (se aparente nos artigos)
- Quais subáreas o trabalho deles abrange
- Um artigo representativo (com link do Consensus)

Isso ajuda os pesquisadores a saberem o trabalho de quem acompanhar e quem são as vozes estabelecidas no campo.

---

### Seção 6: Questões em Aberto e Lacunas

Esta seção é, provavelmente, a mais valiosa para um pesquisador planejando seu próprio trabalho — é de onde vem o próximo artigo. Vá além de afirmações genéricas de "mais pesquisa é necessária".

Estruture as lacunas em três categorias:

**Lacunas metodológicas** — Onde os desenhos de estudo são frágeis?
- Há tópicos apenas com dados observacionais e nenhum ECR?
- Os tamanhos de amostra são consistentemente subdimensionados?
- Há inconsistências de medição ou de definição entre os estudos?

**Lacunas de população/contexto** — Quem ou o que ainda não foi estudado?
- Quais populações estão sub-representadas? (ex.: amostras não ocidentais, faixas etárias específicas, subgrupos clínicos)
- Quais contextos do mundo real estão ausentes? (ex.: estudos apenas em laboratório, não em condições de campo)

**Lacunas conceituais/teóricas** — Que perguntas ninguém fez ainda?
- Há achados contraditórios entre subáreas que ninguém reconciliou?
- Há mecanismos propostos, mas ainda não testados?
- Há campos adjacentes cujos achados não foram integrados?

Para cada lacuna, explique brevemente **por que importa** — não apenas "isto não foi estudado", mas "isto não foi estudado, o que significa que não sabemos se [implicação importante]".

---

### Seção 7: Bibliografia

Uma bibliografia completa de **todos os artigos citados** em qualquer parte do documento.

Formato por entrada:
`Autor(es) (Ano). Título. Periódico.` + hiperlink clicável **"Ver no Consensus"**

Regras:
- Ordene alfabeticamente pelo sobrenome do primeiro autor
- Toda citação no texto deve ter uma entrada correspondente aqui
- Toda entrada deve incluir um **hiperlink clicável "Ver no Consensus"** usando `ExternalHyperlink` com `style: "Hyperlink"`
- Use a **URL completa do Consensus** retornada pela ferramenta — nunca trunque ou encurte URLs
- Nenhum artigo deve aparecer na bibliografia sem ser citado ao menos uma vez no texto

---

### Seção 8: Registro de Auditoria

Esta seção permite que o pesquisador (e quem quer que revise o guia) entenda exatamente como ele foi produzido e quais são suas limitações. Transparência sobre o processo de busca é tão importante quanto os achados — ela permite ao leitor calibrar quanto peso dar à cobertura.

**Tabela-resumo das buscas:**

| # | Consulta de Busca | Filtros Usados | Artigos Retornados | Status |
|---|---|---|---|---|
| 1 | "creatine muscle hypertrophy" | human, year_min: 2015 | 14 | Sucesso |
| 2 | "systematic review creatine strength" | nenhum | 8 | Sucesso |
| 3 | "creatine cognitive function" | human | 0 | Sucesso (sem resultados) |
| 4 | "creatine dosage timing" | nenhum | — | Falhou, nova tentativa bem-sucedida (11) |

**Contagens:**
- Buscas executadas: [N]
- Buscas bem-sucedidas: [N]
- Buscas que falharam (após nova tentativa): [N] — liste quais
- Total de artigos únicos recebidos (deduplicados): [N]
- Artigos citados neste documento: [N]

**Notas de cobertura:**
- Tier do Consensus detectado: [Gratuito (10 resultados/busca) ou Pro (20 resultados/busca)]. Isso foi determinado a partir da resposta da primeira busca.
- Com [N] buscas bem-sucedidas × [10 ou 20] resultados máximos por busca, o teto teórico de artigos trazidos é [N×teto]. Artigos únicos efetivamente recebidos: [N] (devido à deduplicação e a algumas buscas retornarem menos que o teto).
- Quaisquer subáreas com resultados escassos (menos de 5 artigos retornados) devem ser sinalizadas aqui com uma nota como: "A subárea X retornou apenas 3 artigos — a cobertura pode estar incompleta. Considere buscas manuais adicionais no PubMed ou Google Scholar".
- Se algum conteúdo do documento se baseia em conhecimento do modelo, e não em resultados do Consensus, ele é rotulado como `[Não veio do Consensus — conhecimento do modelo]` onde quer que apareça.

---

## Requisitos Técnicos do docx

Siga o skill docx exatamente. Regras-chave:

```javascript
// Setup
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        AlignmentType, LevelFormat, ExternalHyperlink, HeadingLevel,
        BorderStyle, WidthType, ShadingType } = require('docx');

// Página: US Letter, margens de 1 polegada
properties: {
  page: {
    size: { width: 12240, height: 15840 },
    margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
  }
}

// Listas: sempre use LevelFormat.BULLET — nunca bullets unicode
numbering: {
  config: [{
    reference: "bullets",
    levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022",
      alignment: AlignmentType.LEFT,
      style: { paragraph: { indent: { left: 720, hanging: 360 } } } }]
  }]
}

// Hiperlinks: ExternalHyperlink com style "Hyperlink" — nunca trunque URLs
new ExternalHyperlink({
  link: "https://consensus.app/papers/...",   // URL completa retornada pela ferramenta Consensus
  children: [new TextRun({ text: "Ver no Consensus", style: "Hyperlink" })]
})

// Tabelas: larguras duplas (columnWidths + largura da célula), ShadingType.CLEAR
new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: [2000, 3500, 1500, 2360],  // devem somar 9360
  rows: [ new TableRow({ children: [
    new TableCell({
      width: { size: 2000, type: WidthType.DXA },
      shading: { fill: "D5E8F0", type: ShadingType.CLEAR },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [...]
    })
  ]}) ]
})
```

Após salvar, valide:
```bash
python scripts/office/validate.py output.docx
```

Se a validação falhar, descompacte o XML, corrija o problema e recompacte.

---

## Fase 5: Estruturar e Gerar a Apresentação (Manus) — *opcional*

Esta fase só roda **depois** de o guia `.docx` estar pronto e validado, e **somente** se o usuário aceitar. O objetivo é converter o conteúdo do guia em uma apresentação, com o trabalho dividido entre as duas ferramentas: **o Claude estrutura e detalha o conteúdo slide a slide** (com os dados técnicos e as citações já levantados) e **o Manus constrói o arquivo `.pptx`** a partir disso.

O fluxo tem três passos: **(A)** coletar os parâmetros da apresentação, **(B)** o Claude gera o conteúdo de cada slide com detalhes técnicos, **(C)** o Claude monta o prompt final pronto para colar no Manus.

> **Integridade dos dados continua valendo integralmente.** Todo dado técnico (n, tamanhos de efeito, IC, p) e toda citação que aparecer nos slides deve vir do documento/sessão do Consensus. Não invente números, não crie referências e não adicione papers que não foram retornados nesta sessão. Se algo vier de conhecimento do modelo, rotule `[Não veio do Consensus — conhecimento do modelo]`.

---

### Passo A — Coletar os Parâmetros da Apresentação (checkpoint)

Antes de montar qualquer slide, **pergunte ao usuário**. Use `sendPrompt` para as opções de escolha rápida e pergunte em texto livre o que for aberto. Cubra, no mínimo:

**1. Público-alvo** — quem vai assistir define profundidade, jargão e ritmo.
```javascript
sendPrompt("Público: residentes / pós-graduandos")
sendPrompt("Público: especialistas da área")
sendPrompt("Público: banca ou avaliadores (defesa/qualificação)")
sendPrompt("Público: graduação / iniciantes")
sendPrompt("Público: multidisciplinar ou leigo")
```

**2. Duração da apresentação** — controla o número de slides.
```javascript
sendPrompt("Duração: 5-10 min (relâmpago)")
sendPrompt("Duração: 15-20 min (padrão)")
sendPrompt("Duração: 30-45 min (aula completa)")
sendPrompt("Duração: 60+ min (workshop)")
```

**3. Contexto / objetivo** — molda o tom e a ênfase.
```javascript
sendPrompt("Contexto: aula ou treinamento")
sendPrompt("Contexto: journal club")
sendPrompt("Contexto: defesa / qualificação")
sendPrompt("Contexto: congresso / comunicação oral")
sendPrompt("Contexto: reunião clínica ou de equipe")
```

**4. Profundidade técnica** — quanto de método e estatística mostrar.
```javascript
sendPrompt("Profundidade: visão geral conceitual")
sendPrompt("Profundidade: intermediária (achados + alguns números)")
sendPrompt("Profundidade: aprofundada (métodos, n, efeitos, IC, p, limitações)")
```

**5. Perguntas em texto livre** — faça também (em uma única mensagem, de forma enxuta):
- **Idioma dos slides** (português, inglês, bilíngue)
- **Número-alvo de slides** (se o usuário não souber, derive da duração e confirme — ver regra prática abaixo)
- **Estilo/tom visual** (minimalista, acadêmico, clínico, corporativo) e se há **template ou identidade visual/logotipo** a seguir
- **Elementos obrigatórios** (ex.: tabela-síntese de evidências, linha do tempo, fluxograma de decisão, gráfico/forest plot, slide de referências com links, slide de perguntas para discussão)
- **Restrições** (ex.: limite de bullets por slide, slide de conflito de interesses, agradecimentos)

**Regra prática para nº de slides:** ~1 slide por minuto para conteúdo leve; ~1 slide a cada 1,5-2 min para conteúdo técnico denso. Sempre confirme o número final com o usuário antes de gerar.

**Espere as respostas** antes de gerar os slides. Se faltar algum parâmetro essencial (público ou duração), pergunte de novo — não assuma.

---

### Passo B — Claude Gera o Conteúdo Slide a Slide (com detalhes técnicos)

Com os parâmetros em mãos, derive o roteiro de slides a partir das seções do guia. **Mapeamento padrão** (ajuste conforme duração e público):

| Seção do guia | Slide(s) correspondente(s) |
|---|---|
| — | Slide de título (tema, subtítulo, autor, contexto/data) |
| — | Agenda / objetivos de aprendizagem |
| Seção 1 (Visão Geral) | Contexto e relevância do tema |
| Seção 3 (Como o campo chegou aqui) | Linha do tempo *(omitir em durações curtas)* |
| Seção 4 (Guias de subárea) | 1 ou mais slides por subárea (o que a pesquisa mostra + artigos-chave) |
| Seção 2 / Seção 4 | Tabela-síntese das evidências (n, desenho, efeito, citação) |
| Seção 6 (Questões em aberto) | Lacunas e controvérsias |
| — | Mensagens-chave / *take-home* |
| — | Perguntas para discussão |
| Seção 7 (Bibliografia) | Referências (com links "Ver no Consensus") |

**Para CADA slide, entregue no chat, em formato estruturado:**
- **Nº e título do slide**
- **Conteúdo (texto do slide):** bullets curtos e objetivos, já com os dados técnicos pertinentes ao nível de profundidade definido — n, %, tamanho de efeito, IC95%, valor de p, ano
- **Notas do apresentador:** 2-4 frases do que falar (o roteiro de voz), no nível técnico do público
- **Sugestão visual:** que elemento usar (tabela, gráfico de barras, *forest plot*, diagrama, fluxograma, ícones) e o que ele deve mostrar
- **Citações:** **(Autor et al., Ano)** + a **URL completa do Consensus** (nunca truncada)

**Calibre densidade e profundidade ao público e à duração:**
- 5-10 min → ~6-8 slides enxutos, uma ideia por slide
- 15-20 min → ~10-15 slides
- 30-45 min → ~18-25 slides, com tabelas e dados
- Banca/especialistas → aprofunde métodos, tamanhos de efeito, IC e limitações
- Iniciantes/leigos → priorize conceito, analogia e mensagem prática; mova a estatística para as notas do apresentador

Como no documento, **sinalize os artigos transversais** (que apareceram em várias subáreas) como slides de leitura obrigatória.

Apresente o roteiro completo ao usuário e **aguarde aprovação ou ajustes** antes do Passo C.

---

### Passo C — Prompt Final para o Manus (pronto para colar)

Depois do conteúdo slide a slide aprovado, gere **um único bloco de prompt** que o usuário copia e cola no Manus, **anexando o `.docx` do guia**. Preencha todos os campos entre colchetes com os parâmetros coletados no Passo A e **cole o roteiro do Passo B** no lugar indicado. Entregue o bloco dentro de uma cerca de código, para o usuário copiar de uma vez.

````
[PROMPT PARA O MANUS — colar no Manus e anexar o guia .docx]

Você é um construtor de apresentações. Crie uma apresentação completa em PowerPoint
(.pptx) a partir do documento anexado (guia de revisão de literatura sobre [TEMA]).

PARÂMETROS DA APRESENTAÇÃO
- Público-alvo: [PÚBLICO]
- Duração: [DURAÇÃO] → [Nº] slides
- Contexto/objetivo: [CONTEXTO]
- Profundidade técnica: [NÍVEL]
- Idioma dos slides: [IDIOMA]
- Estilo visual / template: [ESTILO]
- Elementos obrigatórios: [ex.: tabela-síntese de evidências, linha do tempo,
  slide de referências com links, slide de perguntas para discussão]

INSTRUÇÕES DE CONSTRUÇÃO
1. Siga EXATAMENTE o roteiro slide a slide abaixo — um slide por bloco, na ordem dada.
2. Para cada slide, use o título, os bullets e a sugestão visual indicados; coloque as
   notas do apresentador no campo de anotações do slide.
3. Preserve TODOS os dados técnicos (n, tamanhos de efeito, IC, p) e TODAS as referências
   exatamente como fornecidos — não invente, não altere e não acrescente números ou citações.
4. Mantenha os links "Ver no Consensus" no slide de referências.
5. Densidade: no máximo ~6 bullets por slide; texto conciso; uma ideia por slide.
6. Aplique o estilo visual definido; use tabelas/diagramas onde o roteiro indicar.
7. Exporte o resultado final em .pptx editável.

ROTEIRO SLIDE A SLIDE
[COLAR aqui o conteúdo slide a slide gerado no Passo B — com título, bullets, notas do
apresentador, sugestão visual e citações de cada slide]
````

Lembre o usuário de **anexar o guia `.docx`** ao enviar o prompt ao Manus, e que o `.pptx` exportado é totalmente editável — ele pode pedir ajustes por slide ao próprio Manus depois (ex.: "transforme o slide 4 em fluxograma").

Esse passo fecha o fluxo integrado **Consensus → Claude → Manus**: o Consensus fornece a evidência, o Claude estrutura o guia e o roteiro slide a slide, e o Manus constrói a apresentação.
